<?php
session_start();
require_once '../classes/Database.php';

if (isset($_GET['id'])) {
    $database = new Database();
    $db = $database->getConnection();
    
    $id = $_GET['id'];
    $query = "DELETE FROM orders WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: orders.php");
        exit();
    } else {
        echo "Error deleting record.";
    }
} else {
    header("Location: orders.php");
    exit();
}
?>