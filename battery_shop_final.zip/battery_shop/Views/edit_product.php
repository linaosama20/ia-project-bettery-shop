<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header("Location: index.php");
    exit();
}

require_once '../classes/Database.php';
require_once '../classes/Product.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$db = (new Database())->getConnection();
$product = new Product($db);
$current_product = $product->readOne($_GET['id']);

if (!$current_product) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Battery Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
    <div class="glass-card p-5" style="width: 100%; max-width: 450px;">
        <div class="text-center mb-5">
            <h2 class="fw-bold mb-2" style="background: linear-gradient(to right, #60a5fa, #a78bfa); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; color: transparent;">Edit Product</h2>
            <p class="text-muted small">Update product details below</p>
        </div>
        <form action="../Actions/product_process.php" method="POST">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($current_product['id']); ?>">
            <div class="mb-4">
                <label class="form-label small fw-semibold text-muted ms-1">Product Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($current_product['name']); ?>" required>
            </div>
            <div class="mb-5">
                <label class="form-label small fw-semibold text-muted ms-1">Price ($)</label>
                <input type="number" step="0.01" name="price" class="form-control" value="<?php echo htmlspecialchars($current_product['price']); ?>" required>
            </div>
            <button type="submit" name="update_product" class="btn btn-primary w-100 py-3 fw-bold rounded-3 mb-3">Update Product</button>
            <a href="index.php" class="btn btn-outline-light w-100 py-3 fw-bold rounded-3" style="border-color: var(--surface-border); color: var(--text-muted);">Cancel</a>
        </form>
    </div>
</div>
</body>
</html>
