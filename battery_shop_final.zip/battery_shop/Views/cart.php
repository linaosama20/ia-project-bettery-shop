<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
require_once '../classes/Database.php';

if (isset($_GET['remove'])) {
    $index = $_GET['remove'];
    if (isset($_SESSION['cart'][$index])) {
        if ($_SESSION['cart'][$index]['quantity'] > 1) { $_SESSION['cart'][$index]['quantity'] -= 1; }
        else { unset($_SESSION['cart'][$index]); $_SESSION['cart'] = array_values($_SESSION['cart']); }
    }
    header("Location: cart.php"); exit();
}

if (isset($_POST['checkout']) && !empty($_SESSION['cart'])) {
    $database = new Database(); $db = $database->getConnection();
    foreach ($_SESSION['cart'] as $item) {
        $stmt = $db->prepare("INSERT INTO orders (product_name, price) VALUES (?, ?)");
        for ($i=0; $i<$item['quantity']; $i++) { $stmt->bind_param("sd", $item['name'], $item['price']); $stmt->execute(); }
    }
    unset($_SESSION['cart']); header("Location: orders.php"); exit();
}
$total_sum = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Battery Shop - Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-5 sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">⚡ BATTERY SHOP</a>
            <div class="ms-auto d-flex align-items-center gap-3">
                <a href="cart.php" class="btn btn-primary rounded-pill px-4 btn-sm d-flex align-items-center gap-2">🛒 Cart</a>
                <a href="orders.php" class="btn btn-outline-light rounded-pill px-4 btn-sm d-flex align-items-center gap-2" style="border-color: var(--surface-border);">📋 Orders</a>
                <a href="../logout.php" class="btn btn-danger btn-sm rounded-pill px-4">Logout</a>
            </div>
        </div>
    </nav>
<div class="container pb-5">
    <div class="glass-card p-4 p-md-5">
        <h4 class="mb-4 fw-bold">🛒 Shopping Cart</h4>
        <div class="table-responsive">
            <table class="table align-middle">
                <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th><th>Action</th></tr></thead>
                <tbody>
                    <?php if (!empty($_SESSION['cart'])): ?>
                        <?php foreach ($_SESSION['cart'] as $index => $item): 
                            $sub = $item['price'] * $item['quantity']; $total_sum += $sub; ?>
                            <tr>
                                <td class="fw-semibold text-dark"><?php echo htmlspecialchars($item['name']); ?></td>
                                <td>$<?php echo number_format($item['price'], 2); ?></td>
                                <td><span class="badge bg-primary px-3 py-2 rounded-pill"><?php echo $item['quantity']; ?></span></td>
                                <td><span class="fw-bold" style="color: #4ade80;">$<?php echo number_format($sub, 2); ?></span></td>
                                <td><a href="cart.php?remove=<?php echo $index; ?>" class="btn btn-sm btn-danger rounded-pill px-3">Remove</a></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="py-5 text-center text-muted fw-semibold">Your cart is empty.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mt-5 pt-3" style="border-top: 1px solid var(--surface-border);">
            <h5 class="mb-4 mb-md-0">Total Amount: <span class="fw-bold" style="color: #4ade80;">$<?php echo number_format($total_sum, 2); ?></span></h5>
            <?php if (!empty($_SESSION['cart'])): ?>
                <form method="POST"><button name="checkout" class="btn btn-primary px-5 py-3 fw-bold rounded-pill shadow-sm">Confirm Order</button></form>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>