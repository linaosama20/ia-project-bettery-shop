<?php
session_start();
require_once '../classes/Database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = new Database();
    $db = $database->getConnection();

    $name = $_POST['product_name'];
    $price = $_POST['price'];

    $query = "INSERT INTO orders (product_name, price) VALUES (?, ?)";
    $stmt = $db->prepare($query);
    $stmt->bind_param("sd", $name, $price);

    if ($stmt->execute()) {
        echo "<script>alert('Success! You bought: $name'); window.location.href='orders.php';</script>";
    } else {
        echo "Error in processing your order.";
    }
}
?>