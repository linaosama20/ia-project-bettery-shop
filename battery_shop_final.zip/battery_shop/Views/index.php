<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
require_once '../classes/Database.php';

$total_items_in_cart = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_items_in_cart += $item['quantity'];
    }
}

$database = new Database();
$db = $database->getConnection();

$order_res = $db->query("SELECT COUNT(*) as total FROM orders");
$total_orders = $order_res ? $order_res->fetch_assoc()['total'] : 0;

$products = $db->query("SELECT * FROM products");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Battery Shop - Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark mb-5 sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">⚡ BATTERY SHOP</a>
            <div class="ms-auto d-flex align-items-center gap-3">
                <a href="cart.php" class="btn btn-primary rounded-pill px-4 btn-sm d-flex align-items-center gap-2">
                    🛒 Cart <span class="badge bg-white text-primary rounded-pill"><?php echo $total_items_in_cart; ?></span>
                </a>
                <a href="orders.php" class="btn btn-outline-light rounded-pill px-4 btn-sm d-flex align-items-center gap-2" style="border-color: var(--surface-border);">
                    📋 Orders <span class="badge bg-white text-dark rounded-pill"><?php echo $total_orders; ?></span>
                </a>
                <a href="../logout.php" class="btn btn-danger btn-sm rounded-pill px-4">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container pb-5">
        <div class="row mb-4 align-items-center">
            <div class="col-md-6">
                <h3 class="fw-bold mb-0">Featured Products</h3>
                <p class="text-muted small">Power up your journey with premium batteries.</p>
            </div>
        </div>

        <div class="row g-4">
            <?php if($products && $products->num_rows > 0): ?>
                <?php while($product = $products->fetch_assoc()): ?>
                    <div class="col-md-4 col-lg-3">
                        <div class="glass-card product-card p-3 h-100 text-center position-relative">
                            
                            <?php if(isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                            <div class="position-absolute top-0 end-0 p-2" style="z-index: 10;">
                                <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-outline-light rounded-circle" style="width: 32px; height: 32px; padding: 4px;">✏️</a>
                            </div>
                            <?php endif; ?>

                            <div class="product-img-block overflow-hidden p-2">
                                <img src="../assets/images/<?php echo htmlspecialchars($product['image_filename']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" style="max-height: 140px; max-width: 100%; object-fit: contain; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.1));">
                            </div>
                            
                            <h6 class="fw-bold mb-2 text-truncate px-2"><?php echo htmlspecialchars($product['name']); ?></h6>
                            <p class="fs-5 fw-bold mb-3" style="color: #4ade80;">$<?php echo number_format($product['price'], 2); ?></p>
                            
                            <form action="add_to_cart.php" method="POST" class="mt-auto">
                                <input type="hidden" name="product_name" value="<?php echo htmlspecialchars($product['name']); ?>">
                                <input type="hidden" name="price" value="<?php echo $product['price']; ?>">
                                <button type="submit" class="btn btn-primary w-100 rounded-pill py-2 small fw-semibold">Add to Cart</button>
                            </form>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center mt-5">
                    <div class="glass-card p-5">
                        <span class="fs-1 d-block mb-3">🪫</span>
                        <p class="text-muted fw-semibold">No products found in the database.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>