<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
require_once '../classes/Database.php';
$database = new Database();
$db = $database->getConnection();
$query = "SELECT * FROM orders ORDER BY id DESC";
$result = $db->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Battery Shop - Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .table-hover tbody tr:hover { background-color: rgba(0,0,0,0.05) !important; color: var(--text-main) !important; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-5 sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">⚡ BATTERY SHOP</a>
            <div class="ms-auto d-flex align-items-center gap-3">
                <a href="cart.php" class="btn btn-outline-light rounded-pill px-4 btn-sm d-flex align-items-center gap-2" style="border-color: var(--surface-border);">🛒 Cart</a>
                <a href="orders.php" class="btn btn-primary rounded-pill px-4 btn-sm d-flex align-items-center gap-2">📋 Orders</a>
                <a href="../logout.php" class="btn btn-danger btn-sm rounded-pill px-4">Logout</a>
            </div>
        </div>
    </nav>
    <div class="container pb-5">
        <div class="glass-card p-4 p-md-5">
            <h3 class="mb-4 fw-bold">📋 Order History</h3>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="py-3 px-4">Order ID</th>
                            <th class="py-3 px-4">Product Name</th>
                            <th class="py-3 px-4">Price</th>
                            <th class="py-3 px-4 text-center">Date & Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && $result->num_rows > 0): ?>
                            <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td class="px-4"><span class="fw-bold" style="color: #60a5fa;">#<?php echo $row['id']; ?></span></td>
                                    <td class="px-4 fw-semibold text-dark"><?php echo htmlspecialchars($row['product_name']); ?></td>
                                    <td class="px-4"><span class="badge px-3 py-2 rounded-pill" style="background: rgba(74, 222, 128, 0.2); color: #4ade80;">$<?php echo number_format($row['price'], 2); ?></span></td>
                                    <td class="px-4 text-center text-muted"><small><?php echo isset($row['created_at']) ? $row['created_at'] : date("Y-m-d H:i:s"); ?></small></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="4" class="text-center py-5 text-muted fw-semibold">No orders yet.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>