<?php
class Database {
    private $host = "localhost";
    private $username = "root";
    private $password = ""; 
    private $db_name = "battery_shop"; 
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $temp_conn = new mysqli($this->host, $this->username, $this->password);
            if ($temp_conn->connect_error) {
                die("Connection failed: " . $temp_conn->connect_error);
            }
            $temp_conn->query("CREATE DATABASE IF NOT EXISTS " . $this->db_name);
            $temp_conn->close();

            $this->conn = new mysqli($this->host, $this->username, $this->password, $this->db_name);
            if ($this->conn->connect_error) {
                die("Connection failed: " . $this->conn->connect_error);
            }

            $this->createTables();

        } catch (Exception $e) {
            die("Connection error: " . $e->getMessage());
        }
        return $this->conn;
    }

    private function createTables() {
        $queryUsers = "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL
        )";
        $this->conn->query($queryUsers);

        $queryOrders = "CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_name VARCHAR(255) NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $this->conn->query($queryOrders);
    }
}
?>