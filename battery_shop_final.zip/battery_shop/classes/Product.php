<?php
class Product {
    private $conn;
    private $table_name = "products";

    public function __construct($db) {
        $this->conn = $db;
        $this->createTable();
    }

    public function createTable() {
        $query = "CREATE TABLE IF NOT EXISTS " . $this->table_name . " (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            image_filename VARCHAR(255) NOT NULL
        )";
        $this->conn->query($query);
        $this->seedData();
    }

    private function seedData() {
        $check = $this->conn->query("SELECT COUNT(*) as count FROM " . $this->table_name);
        $row = $check->fetch_assoc();
        if ($row['count'] == 0) {
            $this->create("Premium Car Battery 12V", 120.00, "car_premium.jpg");
            $this->create("Standard Auto Battery 12V", 85.50, "car_standard.jpg");
            $this->create("Heavy Duty Truck 24V", 195.99, "truck_heavy.jpg");
            $this->create("Marine Deep Cycle", 150.00, "marine.jpg");
            $this->create("Solar Storage Battery", 300.00, "solar.jpg");
            $this->create("Motorcycle Gel Battery", 45.00, "motorcycle.jpg");
            $this->create("EV Starter Battery", 250.00, "ev_starter.jpg");
        }
    }

    public function create($name, $price, $image) {
        $query = "INSERT INTO " . $this->table_name . " (name, price, image_filename) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("sds", $name, $price, $image);
        return $stmt->execute();
    }

    public function read() {
        $query = "SELECT * FROM " . $this->table_name;
        return $this->conn->query($query);
    }

    public function readOne($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public function update($id, $name, $price) {
        $query = "UPDATE " . $this->table_name . " SET name = ?, price = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("sdi", $name, $price, $id);
        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
?>