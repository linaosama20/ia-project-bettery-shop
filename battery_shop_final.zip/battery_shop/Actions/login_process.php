<?php
session_start();
require_once '../classes/Database.php';
require_once '../classes/User.php';

if (isset($_POST['login_btn'])) {
    $database = new Database();
    $db = $database->getConnection();
    $user = new User($db);

    $email = $_POST['email'];
    $password = $_POST['password'];

    $loggedInUser = $user->login($email, $password);

    if ($loggedInUser) {
        $_SESSION['user_id'] = $loggedInUser['id'];
        $_SESSION['user_name'] = $loggedInUser['name'];
        $_SESSION['is_admin'] = ($email === 'root@gmail.com');
        header("Location: ../Views/index.php");
        exit();
    } else {
        die("Error: Invalid Email or Password. <a href='../login.php'>Try again</a>");
    }
} else {
    header("Location: ../login.php");
    exit();
}
?>