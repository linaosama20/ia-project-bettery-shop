<?php
require_once '../classes/Database.php';
require_once '../classes/User.php';

if (isset($_POST['signup_btn'])) {
    $database = new Database();
    $db = $database->getConnection();
    $user = new User($db);

    if ($user->signup($_POST['name'], $_POST['email'], $_POST['password'])) {
        header("Location: ../login.php?msg=registered");
    } else {
        echo "Error in registration.";
    }
}
?>