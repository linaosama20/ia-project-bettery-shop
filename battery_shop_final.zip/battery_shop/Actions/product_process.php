<?php
session_start();
require_once '../classes/Database.php';
require_once '../classes/Product.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);

if (isset($_POST['add_product']) && isset($_SESSION['is_admin']) && $_SESSION['is_admin']) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = 'car_standard.jpg'; // default image
    $product->create($name, $price, $image);
    header("Location: ../Views/index.php?msg=added");
    exit();
}

if (isset($_POST['update_product']) && isset($_SESSION['is_admin']) && $_SESSION['is_admin']) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $product->update($id, $name, $price);
    header("Location: ../Views/index.php?msg=updated");
    exit();
}

if (isset($_GET['delete']) && isset($_SESSION['is_admin']) && $_SESSION['is_admin']) {
    $id = $_GET['delete'];
    $product->delete($id);
    header("Location: ../Views/index.php?msg=deleted");
    exit();
}

header("Location: ../Views/index.php");
exit();
?>
